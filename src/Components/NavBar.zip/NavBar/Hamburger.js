import pic from './Images/Hamburger.svg'
const Hamburger = () => {
    return (
        <img src={pic} alt='' />
    );
}
export default Hamburger