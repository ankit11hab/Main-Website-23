import pic from "./Images/Logo.svg";
import './logo.css'

const Logo = () => {
    return ( <img src={pic} className="Logo_img"></img> );
}

export default Logo;