import Crosspic from './Images/Cross.svg'
const Cross = () => {
    return (
        <img src={Crosspic} alt='' />
    );
}
export default Cross